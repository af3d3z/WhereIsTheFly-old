# WhereIsTheFly
WhereIsTheFly is a game in where the player hits a board with at least a single fly in order to kill it and win the game.

TODO:
- [ ] Print the board (without it showing the flies and ideally shows the position of the last hit to the board) the board will be a NxM matrix.
- [ ] Add flies to the board
- [ ] If a hit is directed at the same position a fly is the fly will be catched.
- [ ] If the fly is next to the position the board was hitted the fly will flutter and change its position to an empty cell.
- [ ] The player will choose how many flies will be in the board.
- [ ] If no flies are left at the board the player wins.
### Optional
- [ ] Implement a power-up system with different power-ups.
- [ ] Implement random health points for every fly.
- [ ] Point-like system and rewards.

