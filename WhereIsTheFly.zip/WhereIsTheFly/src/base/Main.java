package base;

/**
 * MainCode class
 * @author Group5
 */
public class Main {

	/**
	 * Main function
	 * @param args
	 */
	public static void main(String[] args) {
		
		
		
	}

}
